import sys
import os
import psutil
sys.path.append("/dbs/agent")
from base.utils.logical_sql import LogicalSql


def get_pid(cmd_name, part_of_cmd_line):
    pid_list = psutil.pids()
    for pid in pid_list:
        try:
            p = psutil.Process(pid)
            if p.name() == cmd_name:
                if part_of_cmd_line:
                    if part_of_cmd_line in " ".join(p.cmdline()):
                        return pid
                else:
                    return pid
        except psutil.NoSuchProcess:
            continue
    return 0


if __name__ == "__main__":
    dbmanager_pid = get_pid("python", "dbs/agent/base/cmd/dbmanager.py")
    os.environ['fpr1nt'] = ""
    os.environ['fpr1nt'] = os.environ['fpr1nt'] + "@" + str(dbmanager_pid)
    pwd = sys.argv[1]
    ret = LogicalSql.decryptPassword(pwd)
    print("pwd:%s" % ret)
